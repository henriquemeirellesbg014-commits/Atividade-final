let marcas = JSON.parse(localStorage.getItem("marcas")) || [];


function adicionar() {

  const marca = document.getElementById("Marcas").value;
  const quantidade = document.getElementById("Quantidade").value;
  const logo = document.getElementById("Logo").value.trim();


  if (marca === "") {
    alert("O campo 'marca' é obrigatório!");
    return;
  }
   if (quantidade === "") {
    alert("O campo 'quantidade' é obrigatório!");
    return;
  }
   if (logo === "") {
    alert("O campo 'logo' é obrigatório!");
    return;
  }
  







  const novamarcas = {
    id: Date.now(),
    marca,
    quantidade,
    logo
    
  };

  marcas.push(novamarcas);

  localStorage.setItem("marcas", JSON.stringify(marcas));
  localStorage.setItem("marcaCadastrado", JSON.stringify(novamarcas));

  return true;

  salvar();
}


function listar() {
  const lista = document.getElementById("lista");
  lista.innerHTML = "";

  marcas.forEach((user) => {
    lista.innerHTML += `
      <tr>
        <td>${user.marca}</td>
        <td>${user.quantidade}</td>
        <td><img src="${user.logo}" width="80" height="80"/></td>
        <td><button onclick="editar(${user.id})">Editar</button>
        <button onclick="remover(${user.id})">Excluir</button></td>
      </tr>
    `;
  });
}


function salvar() {
  localStorage.setItem("marcas", JSON.stringify(marcas));
}

function remover(id) {
  marcas = marcas.filter(u => u.id !== id);


  
  salvar();
  listar();
}
function editar(id) {
  const user = marcas.find(u => u.id === id);

  const novaMarca = prompt("Nova marca:", user.marca);
  const novaQuantidade = prompt("Nova quantidade:", user.quantidade);
  const novaLogo = prompt("Nova logo (link):", user.logo);
  

  user.marca = novaMarca;
  user.quantidade = novaQuantidade;
  user.logo = novaLogo;


  salvar();
  listar();


}