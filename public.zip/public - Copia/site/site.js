let carros = JSON.parse(localStorage.getItem("carros")) || [];
let marcas = JSON.parse(localStorage.getItem("marcas")) || [];
let comprador = JSON.parse(localStorage.getItem("comprador")) || [];

function listar() {
  const lista = document.getElementById("cards-estoque");
  lista.innerHTML = "";

  carros.forEach((user) => {
    lista.innerHTML += `
      <article class="car-card">
        <div class="car-card__plate">
          <span>PLACA</span><strong>${user.placa}</strong>
        </div>

        <div class="car-card__media">
          <span class="car-card__brandtag">${user.marca}</span>
          <img src="${user.img}" width="235" height="127.6">
        </div>

        <div class="car-card__body">
          <h3>${user.modelo}</h3>
          <p class="car-card__meta">${user.ano} · ${user.combus} · 0 km</p>

          <dl class="specs">
            <div>
              <dt>Marca</dt>
              <dd>${user.marca}</dd>
            </div>
            <div>
              <dt>Cor</dt>
              <dd>${user.cor}</dd>
            </div>
          </dl>

          <div class="car-card__footer">
  <span class="preco">R$ ${user.preco}</span>

  <img src="${user.logoperfil}" class="logo-perfil">
</div>
            <div class="logo-wrap">
            </div>                           

          </div>
        </div>
      </article>
    `;
  });
}

function listarMarcas() {
  const lista = document.getElementById("brands-list");
  lista.innerHTML = "";

  if (marcas.length === 0) return;

  marcas.forEach((item) => {
    lista.innerHTML += `
      <div class="brand-chip">
        <img src="${item.logo}" width="50" height="50">
        <strong>${item.marca}</strong>
        <span>${item.quantidade} unidade(s)</span>
      </div>
    `;
  });
}
function listarCompradores() {
    const lista = document.getElementById("lista-compradores");
    lista.innerHTML = "";

    comprador.forEach((user) => {
        lista.innerHTML += `
            <tr>
                <td class="buyer-name">${user.nome}</td>
                <td>${user.veiculoComprado}</td>
                <td><span class="plate-chip">${user.placaVeiculo}</span></td>
                <td>${user.data}</td>
                <td>${user.pagamento}</td>
            </tr>
        `;
    });
}

