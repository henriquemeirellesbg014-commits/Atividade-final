let comprador = JSON.parse(localStorage.getItem("comprador")) || [];


function adicionar() {

  const nome = document.getElementById("Nome").value;
  const veiculoComprado = document.getElementById("VeiculoComprado").value;
  const placaVeiculo = document.getElementById("PlacaVeiculo").value;
  const data = document.getElementById("Data").value;
  const pagamento = document.getElementById("Pagamento").value;
    



  const novaComprador = {
    id: Date.now(),
    nome,
    veiculoComprado,
    placaVeiculo,
    data,
    pagamento
    

  };

  comprador.push(novaComprador);
  
  localStorage.setItem("comprador", JSON.stringify(comprador));
  localStorage.setItem("compradorCadastrado", JSON.stringify(novaComprador));

  return true;

  salvar();
}


function listar() {
  const lista = document.getElementById("lista");
  lista.innerHTML = "";

  comprador.forEach((user) => {
    lista.innerHTML += `
      <tr>
        <td>${user.nome}</td>
        <td>${user.veiculoComprado}</td>
        <td>${user.placaVeiculo}</td>
        <td>${user.data}</td>
        <td>${user.pagamento}</td>
        <td><button onclick="editar(${user.id})">Editar</button>
        <button onclick="remover(${user.id})">Excluir</button></td>
      </tr>
    `;
  });
}


function salvar() {
  localStorage.setItem("comprador", JSON.stringify(comprador));
}

function remover(id) {
  comprador = comprador.filter(u => u.id !== id);


  
  salvar();
  listar();
}
function editar(id) {
  const user = comprador.find(u => u.id === id);

  const novoNome = prompt("Novo nome:", user.nome);
  const novoVeiculo = prompt("Novo veículo:", user.veiculoComprado);
  const novaPlaca = prompt("Nova placa:", user.placaVeiculo);
  const novaData = prompt("Nova data:", user.data);
  const novoPagamento = prompt("Novo pagamento:", user.pagamento);

  user.nome = novoNome;
  user.veiculoComprado = novoVeiculo;
  user.placaVeiculo = novaPlaca;
  user.data = novaData;
  user.pagamento = novoPagamento;

  salvar();
  listar();
}