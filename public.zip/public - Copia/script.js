let marcas = JSON.parse(localStorage.getItem("marcas")) || [];


function adicionar() {

  const marca = document.getElementById("Marca").value;
  const quantidade = document.getElementById("Quantidade").value;

  const novaMarca = {
    id: Date.now(),
    marca,
    quantidade

  };

  marcas.push(novaMarca);

  salvar();
}


function listar() {
  const lista = document.getElementById("lista");
  lista.innerHTML = "";

  marcas.forEach((user) => {
    lista.innerHTML += `
      <tr>
        <td>${user.marca}</td> <td>${user.quantidade}</td>
        <td><button onclick="editar(${user.id})">Editar</button>
        <button onclick="remover(${user.id})">Excluir</button></td>
      </tr>
    `;
  });
}


function salvar() {
  localStorage.setItem("marcas", JSON.stringify(marcas));
}

function remover(id) {
  marcas = marcas.filter(u => u.id !== id);


  
  salvar();
  listar();
}
