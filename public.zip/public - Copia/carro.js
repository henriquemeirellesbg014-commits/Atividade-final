let carros = JSON.parse(localStorage.getItem("carros")) || [];

function adicionar() {

  const modelo = document.getElementById("Modelo").value;
  const marca = document.getElementById("Marca").value;
  const ano = document.getElementById("Ano").value;
  const preco = document.getElementById("Preco").value;
  const placa = document.getElementById("Placa").value;
  const img = document.getElementById("img").value;
  const combus = document.getElementById("combus").value;
  const cor = document.getElementById("cor").value;
  const cambio = document.getElementById("cambio").value;
  const logoperfil = document.getElementById("logoPerfil").value;

  if (!modelo || !marca || !ano || !preco || !placa || !combus || !cor || !cambio || !img || !logoperfil) {
    alert("Há campos vazios ainda. Preencha, por favor!");
    return false;
  }

  const novacarro = {
    id: Date.now(),
    modelo,
    marca,
    ano,
    preco,
    placa,
    combus,
    cor,
    cambio,
    img,
    logoperfil
  };

  carros.push(novacarro);

  localStorage.setItem("carros", JSON.stringify(carros));
  localStorage.setItem("carroCadastrado", JSON.stringify(novacarro));

  return true;
}

function listar() {
  const lista = document.getElementById("lista");
  lista.innerHTML = "";

  carros.forEach((user) => {
    lista.innerHTML += `
      <tr>
        <td>${user.modelo}</td>
        <td>${user.marca}</td>
        <td>${user.ano}</td>
        <td>${user.preco}</td>
        <td>${user.placa}</td>
        <td>${user.combus}</td>
        <td>${user.cor}</td>
        <td>${user.cambio}</td>
        <td><img src="${user.img}" width="40"></td>
        <td><img src="${user.logoperfil}" width="40"></td>
        <td>
          <button onclick="editar(${user.id})">Editar</button>
          <button onclick="remover(${user.id})">Excluir</button>
        </td>
      </tr>
    `;
  });
}

function salvar() {
  localStorage.setItem("carros", JSON.stringify(carros));
}

function remover(id) {
  carros = carros.filter(u => u.id !== id);
  salvar();
  listar();
}
function editar(id) {
  const user = carros.find(u => u.id === id);

  const novoModelo = prompt("Nova modelo:", user.modelo);
  const novoMarca = prompt("Nova marca:", user.marca);
  const novoAno = prompt("Novo ano:", user.ano);
   const novoPreco = prompt("Nova preco:", user.preco);
  const novoPlaca = prompt("Nova placa:", user.placa);
  const novoCombustivel = prompt("Nova combustivel:", user.combus);
    const novaCor = prompt("Nova cor:", user.cor);
  const novaCambio = prompt("Nova cambio:", user.cambio);
    const novaImg = prompt("Nova imagem (link):", user.img);
        const novoLogoPerfil = prompt("Nova logo da marca(Link):", user.logoperfil);



  

  user.modelo = novoModelo;
  user.marca = novoMarca;
  user.ano = novoAno;
  user.preco = novoPreco;
  user.placa = novoPlaca;
  user.combus = novoCombustivel;
  user.cor = novaCor;
  user.cambio = novaCambio;
  user.img = novaImg;
    user.logoperfil = novoLogoPerfil;



  salvar();
  listar();
}